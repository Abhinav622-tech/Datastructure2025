#include <iostream>
using namespace std;
void swap(int * X , int * Y ){
	int temp = *X;
	*X = *Y;
	*Y= temp;
	
}
void sort012(int arr[], int n) {
    int low = 0, mid = 0, high = n - 1;

    while (mid <= high) {
        if (arr[mid] == 0) {
            swap(arr[low], arr[mid]);
            low++;
            mid++;
        } else if (arr[mid] == 1) {
            mid++;
        } else { // arr[mid] == 2
            swap(arr[mid], arr[high]);
            high--;
        }
    }
}

int main() {
    int n;
    cout << "Enter size of array: ";
    cin >> n;

    int arr[n];
    cout << "Enter elements (0, 1, 2): ";
    for (int i = 0; i < n; i++)
        cin >> arr[i];

    sort012(arr, n);

    cout << "Sorted array: ";
    int i;
    for ( i = 0; i < n; i++)
        cout << arr[i] << " ";
    cout << endl;

    return 0;
}
